# Minesweeper for ICS-OS

## Setting up Minesweeper

1. Extract to `ics-os/`.

```console
$ cd ics-os
$ tar xzvf lightsout.tar.gz
$ cd contrib/minesweeper
$ make
$ make install
```

2. Perform the steps to install and run ics-os.

```console
$ cd ../..
$ sudo make
$ sudo make clean
$ sudo make vmdex
$ sudo make floppy
$ sudo make boot-floppy
```

3. Run lightsout.exe inside ics-os

```console
mines.exe
```

## Authors

[Keith Liam Manaloto](github.com/keithliam)
[Juan Miguel Galvez](github.com/jmtgalvez1)
