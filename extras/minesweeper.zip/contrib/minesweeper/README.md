# Minesweeper for ICS-OS

## Setting up Minesweeper

1. Extract `minesweeper.zip` to `ics-os/`.

2. Install Minesweeper.

```console
$ cd ics-os/contrib/minesweeper
$ make
$ make install
```

2. Perform the steps to install and run ICS-OS.

```console
$ cd ../..
$ sudo make
$ sudo make clean
$ sudo make vmdex
$ sudo make floppy
$ sudo make boot-floppy
```

3. Run lightsout.exe inside ics-os

```console
$ mines.exe
```

## Authors

* [Keith Liam Manaloto](github.com/keithliam)
* [Juan Miguel Galvez](github.com/jmtgalvez1)
